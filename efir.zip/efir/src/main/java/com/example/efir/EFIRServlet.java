package com.example.efir;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/submitFIR")
public class EFIRServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    public void init() throws ServletException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); 
        } catch (ClassNotFoundException e) {
            throw new ServletException("MySQL JDBC Driver not found", e);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String incidentDate = request.getParameter("incidentDate");
        String incidentDetails = request.getParameter("incidentDetails");

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/efir", "root", "1984")) {
            String sql = "INSERT INTO reports (name, email, phone, incident_date, incident_details) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, name);
                stmt.setString(2, email);
                stmt.setString(3, phone);
                stmt.setString(4, incidentDate);
                stmt.setString(5, incidentDetails);
                stmt.executeUpdate();
            }
        } catch (SQLException e) {
            throw new ServletException("Cannot insert FIR into database", e);
        }

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<!DOCTYPE html>");
        out.println("<html lang=\"en\">");
        out.println("<head>");
        out.println("<meta charset=\"UTF-8\">");
        out.println("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">");
        out.println("<title>FIR Confirmation</title>");
        out.println("<link rel=\"stylesheet\" href=\"styles.css\">");
        out.println("</head>");
        out.println("<body>");
        out.println("<div class=\"container\">");
        out.println("<h1>FIR Confirmation</h1>");
        out.println("<p>Thank you, " + name + ". Your FIR has been submitted successfully.</p>");
        out.println("<p>Details of the FIR:</p>");
        out.println("<ul>");
        out.println("<li><strong>Name:</strong> " + name + "</li>");
        out.println("<li><strong>Email:</strong> " + email + "</li>");
        out.println("<li><strong>Phone:</strong> " + phone + "</li>");
        out.println("<li><strong>Date of Incident:</strong> " + incidentDate + "</li>");
        out.println("<li><strong>Incident Details:</strong> " + incidentDetails + "</li>");
        out.println("</ul>");
        out.println("</div>");
        out.println("</body>");
        out.println("</html>");
    }
}